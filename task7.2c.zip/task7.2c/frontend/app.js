var express = require('express');
var app = express();
var stringReplace = require('string-replace-middleware');

var KC_URL = process.env.KC_URL || "http://192.168.56.10:8080/auth";
var SERVICE_URL1 = process.env.SERVICE_URL1 || "http://localhost:3000/secured";
var SERVICE_URL2 = process.env.SERVICE_URL2 || "http://localhost:4000/secured";
app.use(stringReplace({
   'SERVICE_URL1': SERVICE_URL1,
   'KC_URL': KC_URL
}));
app.use(stringReplace({
   'SERVICE_URL2': SERVICE_URL2,
   'KC_URL': KC_URL
}));

app.use(express.static('.'))

app.get('/', function(req, res) {
    res.render('index.html');
});

app.get('/client.js', function(req, res) {
    res.render('client.js');
});

app.listen(8000);
